package com.cg.obs.dto;

public class AccountDto {
	
	/*
  		Declaration of variables.
	 */
	
	private String userName;
	private  static long staticAccNo=10000000010L;
	private float balance;
	private int serviceId;
	private long accNo;
	
	
	/*
		Constructor of the DTO class.
	 */
	
	public AccountDto(){}


	public AccountDto(String userName, float balance,int serviceId) {
		super();
		this.userName = userName;
		this.balance = balance;
		this.serviceId=serviceId;
		accNo=++staticAccNo;
	}
	
	
	

	
	public AccountDto(String userName, float balance, int serviceId, long accNo) {
		super();
		this.userName = userName;
		this.balance = balance;
		this.serviceId = serviceId;
		this.accNo = accNo;
	}


	/*
		Getter-Setter to get and set the values.
	 */

	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public long getAccNo() {
		return accNo;
	}


	public  void setAccNo(long accNo) {
		this.accNo = accNo;
	}


	public float getBalance() {
		return balance;
	}


	public void setBalance(float balance) {
		this.balance = balance;
	}


	public int getServiceId() {
		return serviceId;
	}


	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}


	@Override
	public String toString() {
		return "AccountDto [userName=" + userName + ", accNo=" + accNo + ", balance=" + balance + ", serviceId="
				+ serviceId + "]";
	}



	
	
	
	
	

}
