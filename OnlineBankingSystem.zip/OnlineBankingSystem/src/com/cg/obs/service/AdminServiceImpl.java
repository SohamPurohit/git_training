package com.cg.obs.service;

public class AdminServiceImpl implements AdminService{

	@Override
	public String addCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String viewCustomerList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String transactionDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String serviceHandling() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
