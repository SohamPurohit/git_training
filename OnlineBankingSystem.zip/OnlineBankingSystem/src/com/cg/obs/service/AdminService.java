package com.cg.obs.service;

public interface AdminService {
	
	public String addCustomer();
	public String viewCustomerList();
	public String transactionDetails();
	public String serviceHandling();

}
