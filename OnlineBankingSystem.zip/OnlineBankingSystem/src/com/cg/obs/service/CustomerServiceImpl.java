package com.cg.obs.service;

import com.cg.obs.dao.CustomerDao;
import com.cg.obs.dao.CustomerDaoImpl;
import com.cg.obs.dto.AccountDto;
import com.cg.obs.dto.UserDto;

public class CustomerServiceImpl implements CustomerService{
	
	CustomerDao custDao=new CustomerDaoImpl();

	@Override
	public String addCustomer(AccountDto accDto,UserDto userDto) {
		// TODO Auto-generated method stub
		return custDao.addCustomer( accDto,userDto);
	}

	@Override
	public String viewStatement(String userName) {
		return custDao.viewStatement(userName);
		
	
	}

	@Override
	public String viewSummary(String userName) {
		
		return custDao.viewSummary(userName);
	}

	@Override
	public String viewPersonalDetails(String userName) {
		// TODO Auto-generated method stub
		return custDao.viewPersonalDetails(userName);
	}

	@Override
	public String transferAmt() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateDeatails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String requestChequeBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String requestCreditCard() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String checkRequestStatus() {
		// TODO Auto-generated method stub
		return null;
	}

}
