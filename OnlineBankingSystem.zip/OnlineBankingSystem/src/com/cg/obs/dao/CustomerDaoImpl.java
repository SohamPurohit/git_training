package com.cg.obs.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import com.cg.obs.dto.AccountDto;
import com.cg.obs.dto.TransactionDto;
import com.cg.obs.dto.UserDto;

public class CustomerDaoImpl implements CustomerDao{

	StaticTransferDb tDb = new StaticTransferDb();
	StaticCustomerDb cDb=new StaticCustomerDb();
	Set<AccountDto> accountSet=new HashSet<AccountDto>();
	TransactionDto tranDto=new TransactionDto();



	@Override
	public String addCustomer(AccountDto accDto,UserDto userDto) {
		cDb.customerDb.put(accDto, userDto);
		
		tDb.transactionDb.put(accDto,tranDto );
		return null;
	}

	@Override
	public String viewStatement(String userName) {
		accountSet.addAll(tDb.transactionDb.keySet());
		//System.out.println(arrayList);
		String statement="";
		for(AccountDto accDto:accountSet){
			if(accDto.getUserName().equals(userName)){
				TransactionDto tranDto=tDb.transactionDb.get(accDto);
				statement+="Date: "+ tranDto.getDate()+"Transfer Amount: " +tranDto.getAmtTransfer()+"Remaining Balnace: "+tranDto.getBalance()+"\n";

			}
		}
		return statement;
	}

	@Override
	public String viewSummary(String userName) {
		accountSet.addAll(tDb.transactionDb.keySet());
		//System.out.println(arrayList);
		String summary="";
		for(AccountDto accDto:accountSet){
			if(accDto.getUserName().equals(userName)){
				summary+="Account Number: "+accDto.getAccNo()+"Account Balance:  "+accDto.getBalance()+"   ";
			}
		}

		return summary;
	}

	@Override
	public String viewPersonalDetails(String userName) {

		accountSet.addAll(cDb.customerDb.keySet());
		//System.out.println(arrayList);
		String personalDetail="";
		for(AccountDto accDto:accountSet)
		{
			if(accDto.getUserName().equals(userName))
			{
				UserDto userDto=cDb.customerDb.get(accDto);
				personalDetail+=" Name :"+userDto.getCustName()+" Age:"+userDto.getAge()
				+" Aadhar Number :"+userDto.getAadharNo()+" Address :"+userDto.getAddress()
				+" Gender :"+userDto.getGender()+" Phone Number :"+userDto.getPhoneNo();
			}
		}
			return personalDetail;
		}

		@Override
		public String transferAmt() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String updateDeatails() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String requestChequeBook() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String requestCreditCard() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String checkRequestStatus() {
			// TODO Auto-generated method stub
			return null;
		}

	}
