package com.cg.obs.dao;

public interface AdminDao {
	
	public String addCustomer();
	public String viewCustomerList();
	public String transactionDetails();
	public String serviceHandling();

}
