package com.cg.obs.dao;

import java.util.HashMap;

import com.cg.obs.dto.AccountDto;
import com.cg.obs.dto.UserDto;

public class StaticCustomerDb {
	
	public static HashMap<AccountDto,UserDto> customerDb=new HashMap<AccountDto,UserDto>();
	
	static
	{
		customerDb.put(new AccountDto("soham1808",50000,0), new UserDto("soham1808","Soham@1808","Soham Purohit",22,"Male",
				"soham@gmail.com","Bikaner",1234567890L,8288053888L));
		
		customerDb.put(new AccountDto("praveen012",10000,0), new UserDto("praveen012","Praveen@012","Praveen Kumar",25,"Male",
				"praveen@gmail.com","Bihar",2345678901L,9299653888L));	
	}
	public static HashMap<AccountDto, UserDto> getCustomerDb() {
		return customerDb;
	}

	public static void setCustomerDb(HashMap<AccountDto, UserDto> customerDb) {
		StaticCustomerDb.customerDb = customerDb;
	}

	
}
