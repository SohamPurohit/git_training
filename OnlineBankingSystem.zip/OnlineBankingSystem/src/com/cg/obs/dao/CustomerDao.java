package com.cg.obs.dao;

import com.cg.obs.dto.AccountDto;
import com.cg.obs.dto.UserDto;

public interface CustomerDao {
	
	public String addCustomer(AccountDto accDto,UserDto userDto);
	/*
	 * To View the Details Related to Customer and Transaction
	*/
	public String viewStatement(String userName);
	public String viewSummary(String userName);
	public String viewPersonalDetails(String userName);
	
	
	/*
	 * Transfer Functionality
	*/
	public String transferAmt();
	
	
	/*
	 * Update Deatls 
	 */
	
	public String updateDeatails();
	
	/*
	 * Request service functionality
	*/
	
	public String requestChequeBook();
	public String requestCreditCard();
	public String checkRequestStatus();
	
	
	
}
